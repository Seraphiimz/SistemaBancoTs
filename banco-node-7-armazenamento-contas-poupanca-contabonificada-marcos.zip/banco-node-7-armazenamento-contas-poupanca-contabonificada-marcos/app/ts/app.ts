let contaController = new ContaController();

contaController.listar();

const c1 = new Conta('1', 100);
const p1 = new Poupanca('2', 100);
const cb1 = new ContaBonificada('3', 0);

clienteController.listar();

const n = new Nome('4', 'Digite');
const cpf = new Cpf('5', 0);
const c2 = new Conta('6', 200);


console.log('Conta: ' + c1.saldo);

p1.atualizarSaldoAniversario();
console.log('Poupanca: ' + p1.saldo);

cb1.creditar(100);
console.log('Conta Bonificada: ' + cb1.saldo);

console.log('Digite seu nome:' + n.Digite);

c2.removerConta();
console.log('Remover o sua conta:' + c2.saldo);

c2.inserirConta();
console.log('Inserir sua conta:' + c2.saldo);

c2.pesquisarConta();
console.log('Procura a sua conta:' + c2.saldo);




