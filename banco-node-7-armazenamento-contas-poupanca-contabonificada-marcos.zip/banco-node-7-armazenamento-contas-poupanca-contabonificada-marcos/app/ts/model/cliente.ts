class Cliente{
    private _nome: string;
    private _cpf: string;
    private _conta: number;

    constructor(nome: string, cpf: string, conta = 0){
        this._nome = nome;
        this._cpf = cpf;
        this._conta = conta;
    }

    get nome(){
        return this._nome;
    }

    set nome(nome){
        this._nome = nome;
    }

    get cpf(){
        return this._cpf;
    }

    set cpf(cpf){
        this._cpf = cpf;
    }

    get conta(){
        return this._conta;
    }

    set conta(conta){
        this._conta = conta;
    }

    removerCpf(numero: string): void {
        const cpfRemover = this.pesquisar(numero);
        if (cpfRemover) {
            const indiceConta = this.contas.indexOf(contaARemover);
            if (indiceConta > -1) {
                this.contas.splice(indiceConta, 1);
            }
        }
    }


}