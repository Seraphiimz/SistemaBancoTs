class Clientes{
    private Cliente: new Array<Clientes>;{
        this.clientes = new Array<Clientes>();
        const n1 = new Cliente('1', 'Marcos');
        const n2 = new Cliente('2', 'Gustavo');
        this.clientes.push(n1, n2);

        //2.2

        removerCpf(cpf: string): void {
            const cpfRemover = this.pesquisar(cpf);
            if (cpfRemover) {
                const indiceConta = this.contas.indexOf(cpfRemover);
                if (indiceConta > -1) {
                    this.contas.splice(indiceConta, 1);
                }
            }
        }
        pesquisarCpf(cpf: string): cpf {
            return this.contas.find(
                conta => conta.cpf === cpf
            );
        }
        
}

